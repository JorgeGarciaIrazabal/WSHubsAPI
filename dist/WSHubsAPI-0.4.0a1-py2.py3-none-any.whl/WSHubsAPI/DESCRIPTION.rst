This application inspect the code in the server side and creates the necessary files in the client side to easily communicate both sides.

This protocol allows to call server-side functions (only hub classes) from the client and vice versa
