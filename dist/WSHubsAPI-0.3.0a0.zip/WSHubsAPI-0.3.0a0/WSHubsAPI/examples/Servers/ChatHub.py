# -*- coding: utf-8 -*-
from WSHubsAPI.Hub import Hub

class ChatHub(Hub):
    def __init__(self):
        super(ChatHub, self).__init__()
        self.numberOfFunctionsCalled = 0

    def sendToAll(self, name, message):
        self.numberOfFunctionsCalled += 1
        print("Number of functions called from all clients in this hub: %d" % self.numberOfFunctionsCalled)
        conn = self.sender
        self.allClients.onMessage(name,message)
        #we can send to de sender:
        #self.sender.onMessage(str(conn.ID),message)
        #to all clients but the sender
        #self.otherClients.onMessage(str(conn.ID),message)
        #or to a selection of clients
        #self.getClients(lambda x:x.ID > 4).onMessage(str(conn.ID),message)

    def getNumOfClientsConnected(self):
        self.numberOfFunctionsCalled += 1
        client = self.sender
        return len(client.connections), 'this is a test ñññaá'

