This application inspect the code in the server side and creates the necessary files in the client side to easily communicate both sides.


