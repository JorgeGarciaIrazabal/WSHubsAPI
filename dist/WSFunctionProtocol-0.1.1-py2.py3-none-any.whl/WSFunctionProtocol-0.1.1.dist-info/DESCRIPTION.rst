WSFunctionProtocol


