public class ClientBase {
    public  WSHubsApi wsHubsApi;
    public ClientBase(WSHubsApi wsHubsApi){
        this.wsHubsApi = wsHubsApi;
    }
}
